public class UnitTestGraph {
    public static void main(String[] args) {
        DSAGraph graph = new DSAGraph();
        try {
            addNode(graph);
            addEdge(graph);
            hasNode(graph);
            hasEdge(graph);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        
    }

    public static void addNode(DSAGraph graph) {
        graph = new DSAGraph();
        System.out.println("Testing Add nodes...");
        try {
            graph.addVertex("A");
            graph.addVertex("B");
            graph.addVertex("C");

            graph.displayAsList();
            System.out.println();
        } catch (Exception e) {
            System.out.println("Add node Test Failed" + e.getMessage());
        }

        System.out.println("Expected:\nA |\nB |\nC |\n");
    }

    public static void addEdge(DSAGraph graph) {
        graph = new DSAGraph();
        System.out.println("Testing Add edges...");
        try {
            graph.addVertex("A");
            graph.addVertex("B");
            graph.addVertex("C");
            graph.addEdge("A", "B");
            graph.addEdge("B", "C");
            graph.addEdge("A", "C");

            graph.displayAsList();
            System.out.println();
        } catch (Exception e) {
            System.out.println("Add node Test Failed" + e.getMessage());
        }

        System.out.println("Expected:\nA |  B  C\nB |  A  C\nC |  B  A\n");
    }

    public static void hasNode(DSAGraph graph) {
        graph = new DSAGraph();
        System.out.println("Testing Has nodes...");
        try {
            graph.addVertex("A");
            graph.addVertex("B");
            graph.addVertex("C");

            System.out.println(graph.hasVertex("A"));
            System.out.println(graph.hasVertex("J"));
        } catch (Exception e) {
            System.out.println("Has node Test Failed" + e.getMessage());
        }

        System.out.println("Expected: true, false\n");
    }

    public static void hasEdge(DSAGraph graph) {
        graph = new DSAGraph();
        System.out.println("Testing Has edges...");
        try {
            graph.addVertex("A");
            graph.addVertex("B");
            graph.addVertex("C");
            graph.addEdge("A", "B");
            graph.addEdge("A", "C");

            System.out.println(graph.isAdjacent("A", "B"));
            System.out.println(graph.isAdjacent("B", "C"));
        } catch (Exception e) {
            System.out.println("Has edge Test Failed" + e.getMessage());
        }

        System.out.println("Expected: true, false\n");
    }
}
