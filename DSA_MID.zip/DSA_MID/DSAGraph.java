import java.util.*;
import java.io.*;

public class DSAGraph implements Serializable {
    private DSALinkedList cPath = new DSALinkedList();
    private DSALinkedList fPath = new DSALinkedList();
    private possiblePaths[] pplist = new possiblePaths[5000];

    private DSALinkedList vertces;

    public DSAGraph() {
        vertces = new DSALinkedList();
    }

    public DSAGraphVertex getVertex(String label) {
        DSAGraphVertex vertex = null;

        if (!hasVertex(label)) {
            throw new NoSuchElementException("There was no vertex found.:" + label);
        }

        for (Object kb : vertces) {
            if (((DSAGraphVertex) kb).getLabel().equals(label)) {
                vertex = (DSAGraphVertex) kb;
            }
        }

        return vertex;
    }

    public boolean hasVertex(String label) {
        boolean found = false;

        for (Object kb : vertces) {
            if (((DSAGraphVertex) kb).getLabel().equals(label)) {
                found = true;
            }
        }

        return found;
    }

    public boolean hasVertex(DSAGraphVertex vertex) {
        boolean found = false;

        for (Object kb : vertces) {
            if (((DSAGraphVertex) kb).equals(vertex)) {
                found = true;
            }
        }

        return found;
    }

    public int getVertexCount() {
        //count - c
        int c = 0;

        for (Object kb : vertces) {
            c++;
        }

        return c;
    }

    public int getEdgeCount() {
        int c = 0;

        for (Object kb : vertces) {
            for (Object kb2 : ((DSAGraphVertex) kb).getAdjacent()) {
                c++;
            }
        }
        return (c);
    }

    public DSALinkedList getAdjacent(String label) {
        return getVertex(label).getAdjacent();
    }

    public boolean isAdjacent(String label_1, String label_2) {
        boolean adj = false;
        DSAGraphVertex vertex1, vertex2;

        vertex1 = getVertex(label_1);
        vertex2 = getVertex(label_2);

        for (Object kb : (vertex1.getAdjacent())) {
            if (((DSAGraphVertex) kb).equals(vertex2)) {
                adj = true;
            }
        }

        return adj;
    }

    public boolean isAdjacent(DSAGraphVertex vertex1, DSAGraphVertex vertex2) {
        boolean adjacent = false;

        for (Object kb : (vertex1.getAdjacent())) {
            if (((DSAGraphVertex) kb).equals(vertex2)) {
                adjacent = true;
            }
        }

        return adjacent;
    }

    public void displayAsList() {
        for (Object kb : vertces) {
            System.out.print(((DSAGraphVertex) kb).getLabel() + " |");
            for (Object kb2 : ((DSAGraphVertex) kb).getAdjacent()) {
                System.out.print("  " + ((DSAGraphVertex) kb2).getLabel());
            }
            System.out.println();
        }
    }

    public void displayAsMatrix() {
        int numOf_verticies = getVertexCount();
        DSAGraphVertex[] arr;
        int[][] matrix;
        int idx = 0;

        arr = new DSAGraphVertex[numOf_verticies];
        matrix = new int[numOf_verticies][numOf_verticies];

        for (Object kb : vertces) {
            arr[idx] = (DSAGraphVertex) kb;
            idx++;
        }

        for (int i = 0; i < numOf_verticies; i++) {
            for (int j = 0; j < numOf_verticies; j++) {
                if (isAdjacent(arr[i], arr[j])) {
                    matrix[i][j] = 1;
                } else {
                    matrix[i][j] = 0;
                }
            }
        }

        System.out.print(" ");
        for (Object o :vertces ) {
            System.out.print(" | " + ((DSAGraphVertex) o).getLabel());
        }

        for (int i = 0; i < numOf_verticies; i++) {
            System.out.print("\n" + arr[i].getLabel());
            for (int j = 0; j < numOf_verticies; j++) {
                System.out.print(" | " + matrix[i][j]);
            }
        }
        System.out.println();
    }

    public void addVertex(String label) {
        if (hasVertex(label)) {
            throw new IllegalArgumentException("Vertex " + label +
                    " exists in the graph");
        }

        vertces.insertLast(new DSAGraphVertex(label));
    }

    public void addVertex(DSAGraphVertex vertex) {
        if (hasVertex(vertex)) {
            throw new IllegalArgumentException("Vertex " +
                    vertex.getLabel() + " exists in the graph");
        }

        vertces.insertLast(vertex);
    }

    public void addEdge(String label_1, String label_2) {
        addEdge(getVertex(label_1), getVertex(label_2));
    }

    public void addEdge(DSAGraphVertex vertex1, DSAGraphVertex vertex2) {
        if (!isAdjacent(vertex1, vertex2)) {
            vertex1.addEdge(vertex2);
            vertex2.addEdge(vertex1);
        }
    }

    public void removeVertex(String node) throws Exception {
        if (hasVertex(node)) {
            vertces.remove(getVertex(node));
        } else
            System.out.println("No such a node!");
    }

    public void loadFile(String fileName) {
        FileInputStream strm = null;
        InputStreamReader rdr;
        BufferedReader bfr;
        DSALinkedList lines = new DSALinkedList();
        String line;
        String[] edgeVerticies = new String[2];

        try {
            strm = new FileInputStream(fileName);
            rdr = new InputStreamReader(strm);
            bfr = new BufferedReader(rdr);

            line = bfr.readLine();
            while (line != null) {
                lines.insertLast(line);

                line = bfr.readLine();
            }

            bfr.close();
            System.out.println("File read successfully.");
        } catch (FileNotFoundException k) {
            throw new IllegalArgumentException("File " + fileName +
                    " not found");
        } catch (IOException k) {
            System.out.println(k.getMessage());
        }

        for (Object o : lines) {
            edgeVerticies = ((String) o).split(" ");

            for (String s : edgeVerticies) {

                if (!hasVertex(s)) {
                    addVertex(s);
                }
            }

            addEdge(edgeVerticies[0], edgeVerticies[1]);
        }
    }

    // Graph Vertex Class
    private class DSAGraphVertex implements Serializable {
        private String label;
        private DSALinkedList edges;
        private boolean visited;

        private DSAGraphVertex(String label) {
            this.label = label;
            edges = new DSALinkedList();
            visited = false;
        }

        private String getLabel() {
            return label;
        }

        private DSALinkedList getAdjacent() {
            return edges;
        }

        private boolean getVisited() {
            return visited;
        }

        public String toString() {
            return label;
        }

        public boolean equals(DSAGraphVertex vertex) {
            return (label.equals(vertex.getLabel()));
        }

        private void addEdge(DSAGraphVertex vertex) {
            edges.insertLast(vertex);
        }

        private void setVisited() {
            visited = true;
        }

        private void clearVisited() {
            visited = false;
        }

    }

    // Path object class
    public class possiblePaths {
        String p;//path
        int l;//length

        public possiblePaths(String path, int length) {
            this.p = path;
            this.l = length;
        }
    }

    // Reference: https://www.baeldung.com/cs/simple-paths-between-two-vertices

    //s - starting point 
    //e - end point
    public void getPaths(String s_Point, String e_Point) throws Exception {
        try {
            DSAGraphVertex s = getVertex(s_Point);
            DSAGraphVertex e = getVertex(e_Point);

            if (s.getVisited()) {
                return;
            }
            s.setVisited();
            cPath.insertLast(s);
            if (s == e) {
                DSALinkedList copyList = new DSALinkedList();
                Object c;
                for (Object o : cPath) {
                    c = (Object) o;
                    copyList.insertLast(c);

                }
                fPath.insertLast(copyList);
                s.clearVisited();
                cPath.removeLast();
                return;
            }
            for (Object o : s.getAdjacent()) {
                DSAGraphVertex currentVertex = (DSAGraphVertex) o;
                getPaths(currentVertex.getLabel(), e.getLabel());
            }
            cPath.removeLast();
            s.clearVisited();

        } catch (Exception e) {
            System.out.println("No paths");
        }

    }

    public void printPath() {
        String path = "";
        int hope = -1;
        DSALinkedList list;
        int j = 0;
        for (Object o1 : fPath) {
            list = (DSALinkedList) o1;

            Object cc;
            for (Object o2 : list) {
                cc = (Object) o2;
                path += cc.toString() + " -> ";
                hope++;
            }
            pplist[j] = new possiblePaths(path, hope);
            path = "";
            hope = -1;
        }

        possiblePaths shortest_path = pplist[0];
        int shortest_length = pplist[0].l;
        for (int i = 0; i < pplist.length; i++) {
            if(pplist[i] != null){
                if (pplist[i].l < shortest_length) {
                    shortest_path = pplist[i];
                }
            }
        }

        System.out.println(shortest_path.p);
        shortest_path = null;

        for (int i = 0; i < pplist.length; i++) {
            pplist[i] = null;
        }

    }

    public void saveKeyboard(DSAGraph graph, String fileName) throws Exception {
        FileOutputStream fileStream;
        ObjectOutputStream objectStream;
        try {
            fileStream = new FileOutputStream(fileName);
            objectStream = new ObjectOutputStream(fileStream);
            objectStream.writeObject(graph);
            objectStream.close();
            System.out.println("Keyboard saved (File name: " + fileName + ")");
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    public void clearLists() throws Exception {
        while (!fPath.isEmpty()) {
            fPath.removeLast();
        }

        while (!cPath.isEmpty()) {
            cPath.removeLast();
        }
    }
}
