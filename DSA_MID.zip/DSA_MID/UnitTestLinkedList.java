public class UnitTestLinkedList {

    public static void main(String[] args) {
        DSALinkedList testList = new DSALinkedList();
        try {
            insert(testList);
            removel(testList);
            empty(testList);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void insert(DSALinkedList testList) throws Exception {

        try {
            testList = new DSALinkedList();
            System.out.println("Testing insertion...");

            testList.insertFirst("A");
            testList.insertFirst("B");
            testList.insertFirst("C");
            testList.insertLast("D");
            testList.insertLast("E");
            testList.insertLast("F");

            System.out.println("Peek first: " + testList.peekFirst() + "   Peek Last: " + testList.peekLast());

        } catch (Exception e) {
            throw new Exception("Insert Test Failed\n " + e.getMessage());
        }
        System.out.println("Expected (Peek first: C   Peek Last: F)\n");
    }

    public static void removel(DSALinkedList testList) throws Exception {

        try {
            testList = new DSALinkedList();
            System.out.println("Testing removel...");

            testList.insertFirst("A");
            testList.insertFirst("B");
            testList.insertFirst("C");
            testList.insertLast("D");
            testList.insertLast("E");
            testList.insertLast("F");

            testList.removeFirst();
            testList.removeLast();

            System.out.println("Peek first: " + testList.peekFirst() + "   Peek Last: " + testList.peekLast());

        } catch (Exception e) {
            throw new Exception("Remove Test Failed\n " + e.getMessage());
        }
        System.out.println("Expected (Peek first: B   Peek Last: E)\n");
    }

    public static void empty(DSALinkedList testList) {

        try {
            testList = new DSALinkedList();
            System.out.println("Testing empty list...");

            System.out.println(testList.isEmpty());

        } catch (Exception e) {
            System.out.println("Empty Test Failed\n " + e.getMessage());
        }
        System.out.println("Expected ('true')\n");
    }
}
