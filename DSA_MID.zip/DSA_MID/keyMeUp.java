import java.util.Scanner;

public class keyMeUp {
    public static DSAGraph dsaGraph = new DSAGraph();

    public static void main(String[] args) throws Exception {
        if (args.length < 1) {
            System.out.println("-i : interactive testing environment (keyMeUp -i) \n" +
                    "-s : silent mode (keyMeUp -s keyFile strFile pathFile)");
        } else if (args.length == 1 && args[0].equals("-i")) {
            interactive();
        } else if (args.length == 4 && args[0].equals("-s")) {
            silent(args[1], args[2], args[3]);
        } else {
            System.out.println("Invalid arguments!");
            System.out.println("-i : interactive testing environment (keyMeUp -i) \n" +
                    "-s : silent mode (keyMeUp -s keyFile strFile pathFile)");
        }
    }

    public static void interactive() throws Exception {
        Scanner sc = new Scanner(System.in);
        int input;
        String inputString = "";
        char[] charArray;
        do {
            System.out.println("(1) Load keyboard file\n" +
                    "(2) Node operations (find, insert)\n" +
                    "(3) Edge operations (find, add)\n" +
                    "(4) Display graph\n" +
                    "(5) Display graph information\n" +
                    "(6) Enter string for finding path\n" +
                    "(7) Generate & Display paths\n" +
                    "(8) Save keyboard\n" +
                    "(9) Quit");
            input = sc.nextInt();

            switch (input) {
                case 1:
                    System.out.println("please Enter name of the file:");
                    dsaGraph.loadFile(sc.next());
                    System.out.println();

                    break;
                case 2:
                    nodeOperations();

                    break;
                case 3:
                    edgeOperations();

                    break;
                case 4:
                    dsaGraph.displayAsMatrix();
                    System.out.println("");

                    break;
                case 5:
                    System.out.println("Graph information");
                    System.out.println("Node count: " + dsaGraph.getVertexCount());
                    System.out.println("Edge count: " + dsaGraph.getEdgeCount());
                    System.out.println();

                    break;
                case 6:
                    try {
                        System.out.println("Enter the string: ");
                        inputString = sc.next();
                    } catch (Exception e1) {
                        e1.printStackTrace();
                    }

                    break;
                case 7:

                    System.out.println("Generating paths...");

                    charArray = new char[inputString.length()];
                    for (int i = 0; i < inputString.length(); i++) {
                        charArray[i] = inputString.charAt(i);
                    }
                    for (int i = 0; i < charArray.length - 1; i++) {
                        dsaGraph.getPaths(String.valueOf(charArray[i]), String.valueOf(charArray[i + 1]));
                        dsaGraph.printPath();
                        dsaGraph.clearLists();
                    }

                    break;
                case 8:
                    try {
                        dsaGraph.saveKeyboard(dsaGraph, "savedKeyboard");
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    System.out.println();
                    break;
                case 9:
                    System.out.println("exit.");
                    System.out.println();
                    break;

                default:
                    System.out.println("Invalid input!");
                    System.out.println();
                    break;
            }

        } while (input != 0);
        sc.close();
    }

    public static void silent(String keyFile, String strFile, String pathFile) {
        Scanner sc = new Scanner(System.in);
        try {
            dsaGraph.loadFile(keyFile);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        sc.close();
    }

    public static void nodeOperations() {
        Scanner sc = new Scanner(System.in);
        int input;
        System.out.println("(1) Find\n" +
                "(2) Insert\n");
        input = sc.nextInt();
        switch (input) {
            case 1:
                System.out.println("Enter Node to find:");
                String f_node = sc.next();
                if (dsaGraph.hasVertex(f_node)) {
                    System.out.println("Found");
                } else {
                    System.out.println("Not found");
                }
                System.out.println();
                break;

            case 2:
                System.out.println("Enter Node to add:");
                String a_node = sc.next();
                try {
                    dsaGraph.addVertex(a_node);
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
                System.out.println();
                break;

            default:
                System.out.println("Invalid input!\n");
                break;
        }
    }

    public static void edgeOperations() {
        Scanner sc = new Scanner(System.in);
        int input;
        System.out.println("(1) Find\n" +
                "(2) Insert\n");
        input = sc.nextInt();
        switch (input) {
            case 1:
                System.out.println("Enter starting node to find edge:");
                String f_start = sc.next();
                System.out.println("Enter destination node to find edge:");
                String f_destination = sc.next();

                if (dsaGraph.isAdjacent(f_start, f_destination)) {
                    System.out.println("Found");
                } else {
                    System.out.println("Not found");
                }
                System.out.println();
                break;

            case 2:
                System.out.println("To add an edge, enter the starting node.:");
                String a_start = sc.next();
                System.out.println("To add an edge, type the destination node.:");
                String a_destination = sc.next();
                try {
                    dsaGraph.addEdge(a_start, a_destination);
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
                System.out.println();
                break;

            default:
                System.out.println("Invalid input!\n");
                break;
        }
    }

}
