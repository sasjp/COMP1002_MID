import java.util.*;
import java.io.*;

public class DSALinkedList implements Iterable, Serializable {
    private DSAListNode h, t;

    public DSALinkedList() {
        //head-h
        //tail -t
        h = null;
        t = null;
    }

    public boolean isEmpty() {
        boolean empty = false;

        empty = h == null;

        return empty;
    }

    public Object peekFirst() throws Exception {
        Object nodeValue;

        if (!isEmpty()) {
            nodeValue = h.getValue();
        } else {
            throw new Exception("Empty List");
        }

        return nodeValue;
    }

    public Object peekLast() throws Exception {
        Object nodeValue;

        if (!isEmpty()) {
            nodeValue = t.getValue();
        } else {
            throw new Exception("Empty List");
        }

        return nodeValue;
    }

    public void insertFirst(Object value) {
        DSAListNode newNode = new DSAListNode(value);

        if (isEmpty()) {
            h = newNode;
            t = newNode;
        } else {
            newNode.setNext(h);
            h.setPrev(newNode);
            h = newNode;
        }
    }

    public void insertLast(Object value) {
        DSAListNode newNode = new DSAListNode(value);

        if (isEmpty()) {
            h = newNode;
            t = newNode;
        } else {
            t.setNext(newNode);
            newNode.setPrev(t);
            t = newNode;
        }
    }

    public Object removeFirst() throws Exception {
        Object node;

        if (isEmpty()) {
            throw new Exception("Empty List");
        } else if (h.getNext() == null) {
            node = h.getValue();
            h = null;
            t = null;
        } else {
            node = h.getValue();
            h = h.getNext();
        }

        return node;
    }

    public Object removeLast() throws Exception {
        Object node;

        if (isEmpty()) {
            throw new Exception("Empty List");
        } else if (t.getPrev() == null) {
            node = t.getValue();
            h = null;
            t = null;
        } else {
            node = t.getValue();
            t.getPrev().setNext(null);
            t = t.getPrev();
        }

        return node;
    }

    public void remove(Object key) throws Exception {
        DSAListNode node = h;
        boolean found = false;

        try {
            if (h.getValue() == key) {
                removeFirst();
            } else if (t.getValue() == key) {
                removeLast();
            } else {
                while ((!found) && (node != null)) {
                    if (node.getValue() == key) {
                        found = true;
                        node.getNext().setPrev(node.getPrev());
                        node.getPrev().setNext(node.getNext());
                    }
                    node = node.getNext();
                }
            }
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    public Iterator iterator() {
        return new LinkedListIterator(this);
    }

    // Linked List Node Class
    private class DSAListNode implements Serializable {
        private Object value;
        private DSAListNode prev, next;

        public DSAListNode(Object value) {
            this.value = value;
            prev = null;
            next = null;
        }

        public Object getValue() {
            return value;
        }

        public DSAListNode getPrev() {
            return prev;
        }

        public DSAListNode getNext() {
            return next;
        }

        public void setValue(Object value) {
            this.value = value;
        }

        public void setPrev(DSAListNode node) {
            prev = node;
        }

        public void setNext(DSAListNode node) {
            next = node;
        }
    }

    // Linked List Iterator Class
    private class LinkedListIterator implements Iterator, Serializable {
        private DSAListNode iterNext;

        public LinkedListIterator(DSALinkedList linkedList) {
            iterNext = linkedList.h;
        }

        public boolean hasNext() {
            return iterNext != null;
        }

        public Object next() {
            Object value;

            if (iterNext == null) {
                value = null;
            } else {
                value = iterNext.getValue();
                iterNext = iterNext.getNext();
            }

            return value;
        }
    }

}
